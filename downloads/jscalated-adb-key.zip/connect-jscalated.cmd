@echo off
setlocal
if "%~1"=="" (
  echo Usage: connect-jscalated.cmd PHONE_WIFI_IP
  exit /b 2
)
if not exist "%~dp0adb.exe" (
  echo Copy adbkey, adbkey.pub, and this file into your Android platform-tools folder.
  exit /b 3
)
set "ADB_VENDOR_KEYS=%~dp0adbkey"
set "SERIAL=%~1:5555"
"%~dp0adb.exe" kill-server >nul 2>&1
"%~dp0adb.exe" start-server || exit /b 4
"%~dp0adb.exe" connect %SERIAL%
"%~dp0adb.exe" -s %SERIAL% get-state 2>nul | findstr /X /C:"device" >nul
if errorlevel 1 (
  "%~dp0adb.exe" disconnect %SERIAL% >nul 2>&1
  "%~dp0adb.exe" connect %SERIAL%
  "%~dp0adb.exe" -s %SERIAL% get-state 2>nul | findstr /X /C:"device" >nul
  if errorlevel 1 (
    echo Phone did not reach ADB device state at %SERIAL%.
    echo Check the phone's Wi-Fi IP and that wireless ADB is listening.
    exit /b 6
  )
)
"%~dp0adb.exe" -s %SERIAL% shell
exit /b %errorlevel%
