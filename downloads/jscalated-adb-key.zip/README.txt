JScalated 3.0 community ADB key

Extract adbkey, adbkey.pub, and connect-jscalated.cmd into your Android
platform-tools directory (beside adb.exe). On a computer connected to the
same Wi-Fi network as the phone, run:

  connect-jscalated.cmd PHONE_WIFI_IP

This key pair is shared by JScalated users. The private key in this download
matches the public key placed on the phone by the JScalated 3.0 XPI.
The command file starts the normal ADB server with that key. Later plain
adb commands use the same server until it is stopped or the computer restarts.
